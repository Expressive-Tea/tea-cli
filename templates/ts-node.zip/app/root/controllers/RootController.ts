import { Route } from '@zerooneit/expressive-tea/decorators/router';

@Route('/')
export default class RootController {

}
